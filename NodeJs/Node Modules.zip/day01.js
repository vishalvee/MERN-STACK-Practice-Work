
//---MODULES----

//for file
const fs=require('fs');
//for path
const path = require('path');
fs.writeFileSync('data.txt',"This is first txt file");
const read=fs.readFileSync('data.txt','utf-8')
console.log(read);
//path
const filePath = path.join(__dirname,'myfolder','data.txt');
console.log(path.basename(filePath)); //path.basename() --- it shows the file with extension like [data.txt]
console.log(path.extname(filePath)); //path.extname() --- it shows only the Extension of file like [.txt]

//Append
fs.appendFile('data.txt','\nThis is new content using Append',(err)=>{
    if(err){
        console.log('Error',(err));
    }else(console.log('Successfuly Done'));
})

//Os 
const os = require('os');
console.log('OS Type:', os.type());
console.log('Platform:', os.platform());
console.log('Free Memory:', os.freemem());
console.log('Total Memory:', os.totalmem());
console.log('Uptime:', os.uptime());
console.log('User Info:', os.userInfo());
